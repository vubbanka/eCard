<?php

defined('_JEXEC') or die();

/**
 * VubBtn plugin
 *
 * see: https://dev.virtuemart.net/projects/virtuemart/wiki/Payment_Plugins
 *
 * @author ForBestClients
 * @version 0.01
 * @package VirtueMart
 * @subpackage payment
 * @copyright Copyright (C) ForBestClients
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */
if (!class_exists('vmPSPlugin')) {
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
}
if (!class_exists('VubEcard')) {
    //require(VMPATH_ROOT . DS . 'plugins' . DS . 'vmpayment' . DS . 'vubbtn' . DS . 'vubbtn' . DS . 'VubBtnClass.php');
    //require(dirname(__FILE__) . DS . 'vub-ecard-master' . DS .  'lib' . DS . 'VubEcard.php');
    require(dirname(__FILE__) . DS . 'vub-ecard-master' . DS .  'lib' . DS . 'autoload.php');
}

//compatibility joomle 2.5
if (!class_exists('vRequest')) {
    class vRequest extends JRequest
    {

    }
}
if (!class_exists('vmText')) {
    class vmText extends JText
    {

    }
}

//class plgVmPaymentVubBtn extends vmPaymentPlugin
class plgVmPaymentVubBtn extends vmPSPlugin
{

    const PARAM_DEMO_MODE = 'DEMO';
    const PARAM_CID = 'CID';
    const PARAM_KEY = 'KEY';
    const PARAM_VS = 'VS';
    const PARAM_TYPE = 'TYPE'; //or BIC/SWIFT
    const PARAM_CURR = 'CURR';
    const PARAM_RU = 'RU';
    const PARAM_AMNT = 'AMNT';
    const PARAM_RESULT = 'RESULT';
    const PARAM_SIGN = 'SIGN';
    const PARAM_EMAIL = 'EMAIL';

    const BANK_STATE_OK = 'OK';
    const BANK_STATE_KO = 'FAIL';
    //currency
    const CURR_EURO = 978;

    function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);

        // 		vmdebug('Plugin vubbtn',$subject, $config);

        $this->_loggable = TRUE;
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';

        $varsToPush = $this->getVarsToPush();
        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
    }

    /**
     * Create the table for this plugin if it does not yet exist.
     *
     */
    public function getVmPluginCreateTableSQL()
    {
        return $this->createTableSQL('Payment VubBtn Table');
    }

    /**
     * Fields to create the payment table
     *
     * @return string SQL Fileds
     */
    function getTableSQLFields()
    {

        $SQLfields = array(
            'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
            'order_number' => 'char(64)',
            'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
            'virtuemart_order_id' => 'int(1) UNSIGNED',
            'cid' => 'varchar(10)',
            'payment_name' => 'varchar(50)', //desc
            'amnt' => 'decimal(15,2) NOT NULL DEFAULT \'0.00\'', //amnt
            'curr' => 'char(3)', // EUR
            'bic' => 'char(10)', // bic/swift code
            'vs' => 'varchar(10)', //variable symbol
            //response
            'payment_date' => 'datetime',
            'result' => 'varchar(8)', //OK/FAIL/Pending
        );

        return $SQLfields;
    }

    /////////////////// confirmed - request ////////////////////////
    /**
     *
     * @param $cart
     * @param $order
     * @return bool|null|void
     */
    function plgVmConfirmedOrder($cart, $order)
    {

        if (!($this->_currentMethod = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {
            return false;
        }

        if (!class_exists('VirtueMartModelOrders')) {
            require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
        }

        //prepare data
        $vs = str_pad($cart->virtuemart_order_id, 10, "0", STR_PAD_LEFT);
        $amnt = 0 + $order['details']['BT']->order_total;
        $amnt = number_format($amnt, 2, '.', '');

        $ruOk = JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id . '&bs=OK');
        $ruFail = JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id . '&bs=FAIL');

        $orderInfo = unserialize($_SESSION['__vm']['vmcart']);
        if(isset($orderInfo->BT) && !empty($orderInfo->BT)) {
            if(isset($orderInfo->BT['email']) && !empty($orderInfo->BT['email'])) {
                $email = $orderInfo->BT['email'];
            }
        }

        $vubbtn_demo = $this->_currentMethod->vubbtn_demo;
        try {
            $vubbtn = new \VubEcard\VubEcard( trim($this->_currentMethod->vubbtn_cid), trim($this->_currentMethod->vubbtn_key), null, $vubbtn_demo );

            /*
            if(!$vubbtn->validateCredentials()) {
                vmInfo(vmText::_('VMPAYMENT_VUBBTN_UNVALID_CREDENTIALS'));
                $html = '<br/>'.vmText::_('VMPAYMENT_VUBBTN_ADMINISTRATOR');
                //clear title and text thank you ...
                vRequest::setVar('html', $html);
                vRequest::setVar('display_title', false);

                return false;
            }
            */

            $vubbtn->setCallbackUrlSuccesfull($ruOk);
            $vubbtn->setCallbackUrlError($ruFail);
            $vubbtn->setOrderDetails($vs, 0 + $amnt);
        } catch (Exception $e) {
            vmInfo($e->getMessage());
            //clear title and text thank you ...
            vRequest::setVar('html', '');
            vRequest::setVar('display_title', false);

            $html = '<br/>'.vmText::_('VMPAYMENT_VUBBTN_ADMINISTRATOR');

            //clear title and text thank you ...
            vRequest::setVar('html', $html);
            vRequest::setVar('display_title', false);

            return false;
        }
        
        $payment_name = $this->renderPluginName($this->_currentMethod, $order);

        // Prepare data that should be stored in the database
        $dbValues = array();
        $dbValues['order_number'] = $order['details']['BT']->order_number;
        $dbValues['virtuemart_paymentmethod_id'] = $cart->virtuemart_paymentmethod_id;
        $dbValues['virtuemart_order_id'] = $cart->virtuemart_order_id; //=vs
        $dbValues['cid'] = trim($this->_currentMethod->vubbtn_cid);
        $dbValues['payment_name'] = strip_tags($payment_name);
        $dbValues['amnt'] = $amnt;
        $dbValues['curr'] = 'EUR';
        $dbValues['vs'] = $vs;
        $dbValues['amnt'] = $amnt;
        $dbValues['result'] = 'Pending';

        $this->storePSPluginInternalData($dbValues);

        //redirecto vubbtn payment portal

        $ruRedirect = (JROUTE::_(JURI::root() . 'plugins/vmpayment/vubbtn/vub-redirect/vub-redirect.html?' . $this->generatePostString($vubbtn) . '&vmCart=' . urlencode(JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=cart') )));
        $app = JFactory::getApplication();
        $app->redirect($ruRedirect);

        return true;
    }

    //////////////////// response from gateway ////////////
    /**
     *   This event is fired after the asynchronous payment response has been received
     *
     */
    function plgVmOnPaymentResponseReceived(&$html, &$paymentResponse)
    {
        if (!class_exists('VirtueMartCart')) {
            require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
        }
        if (!class_exists('shopFunctionsF')) {
            require(VMPATH_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
        }
        if (!class_exists('VirtueMartModelOrders')) {
            require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
        }
        VmConfig::loadJLang('com_virtuemart_orders', TRUE);

        //$virtuemart_paymentmethod_id = vRequest::getInt('pm', '');
        $order_number = vRequest::getString('on', 0);
        $isUrlOk =  vRequest::getString('bs');

        $virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($order_number);
        if (!$virtuemart_order_id) {
            return null;
        }

        $db = JFactory::getDBO();
        $_q = "SELECT * FROM `{$this->_tablename}` WHERE `virtuemart_order_id` = '{$virtuemart_order_id}'";
        $db->setQuery($_q);
        $vubbtnData = $db->loadAssoc();
        $virtuemart_paymentmethod_id = $vubbtnData['virtuemart_paymentmethod_id'];
        if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }

        $postValues = $_POST;

        $vubbtn = new \VubEcard\VubEcard( trim($this->_currentMethod->vubbtn_cid), trim($this->_currentMethod->vubbtn_key), null, false );
        $vubbtn->setOrderDetails($vubbtnData['vs'], 0 + $vubbtnData['amnt']);

        if( $isUrlOk == self::BANK_STATE_OK ) {
            try {
                if ($vubbtn->validateResponse($postValues)) {
                    //save status "C" == Confirmed
                    $order_data = array('order_status' => 'C');
                    $modelOrder = VmModel::getModel('orders');
                    $modelOrder->updateStatusForOneOrder($virtuemart_order_id, $order_data, true);

                    //update vubbtn data
                    $vubbtnData['payment_date'] = date('Y-m-d H:i:s');
                    $vubbtnData['result'] = $postValues['Response'];
                    $this->storePSPluginInternalData($vubbtnData, 'virtuemart_order_id', true);

                    //and clear cart
                    $cart = VirtueMartCart::getCart();
                    $cart->emptyCart();
                    // and clear any previous errors texts
                    $html = '';

                    return true;
                } else {
                    $error = $this->getErrorMsg($postValues);
                }
            } catch (\VubEcard\VubException $e) {
                $error = $e->getMessage();
            }
        } else {
            $error = $this->getErrorMsg($postValues);
        }

        if ($error) {
            $error = vmText::_('VMPAYMENT_VUBBTN_PAYMENT_NOT_VALID') . '<br/> error: ' . $error;
            $html = $error;
            $cartUrl = JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=cart');
            $backToCart = vmText::_('VMPAYMENT_VUBBTN_BACK_TO_CART');
            $html .= '<br/><a href="'.$cartUrl.'">' . $backToCart . '</a>';

            $paymentResponse = '';
            //clear title and text thank you ...
            vRequest::setVar('html', '');
            vRequest::setVar('display_title', false);

            return false;
        }

        /* VUB nema cancel tlacidlo */
        /*
            //save status "X" Cancelled
            $order_data = array('order_status' => 'X');
            $modelOrder = VmModel::getModel('orders');
            $modelOrder->updateStatusForOneOrder($virtuemart_order_id, $order_data, false);
            $cancelURL = JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginUserPaymentCancel&po=');
            $app = JFactory::getApplication();
            $app->redirect($cancelURL);

            return false;
        */
    }

    /**
     * because VUB returns ... what VUB returns
     *
     * @$postValues POST returned from VUB eCard
     * @return error message
     *
     */
    // because VUB returns ... what VUB returns
    protected function getErrorMsg($postValues) {
        $retError = vmText::_('VMPAYMENT_VUBBTN_UNSPECIFIED_ERROR');
        if(isset($postValues['ErrMsg'])) {
            $retError = $postValues['ErrMsg'];
        }
        if(isset($postValues['mdErrorMsg'])) {
            $retError = $postValues['mdErrorMsg'];
        }
        return $retError;
    }

    function getFakePostValues() {
        $postValues = array();
        $postValues['clientid'] = vRequest::getString('clientid');
        $postValues['oid'] = vRequest::getString('oid');
        $postValues['rnd'] = vRequest::getString('rnd');
        // $postValues['Response'] = vRequest::getString('Response');
        $postValues['Response'] = 'Approved';
        //$postValues['ErrMsg'] = vRequest::getString('ErrMsg');
        $postValues['ErrMsg'] = '';
        //$postValues['mdStatus'] = vRequest::getString('mdStatus');
        $postValues['mdStatus'] = 1;
        //$postValues['ProcReturnCode'] = vRequest::getString('ProcReturnCode');
        $postValues['ProcReturnCode'] = '00';
        $postValues['HASHPARAMS'] = vRequest::getString('HASHPARAMS');
        $postValues['HASHPARAMSVAL'] = vRequest::getString('HASHPARAMSVAL');
        // $postValues['HASH'] = vRequest::getString('HASH');
        $postValues['HASH'] =  str_replace('test','', vRequest::getString('HASH'));
        $postValues['hashAlgorithm'] = vRequest::getString('hashAlgorithm');

        return $postValues;
    }

    /**
     * Create the table for this plugin if it does not yet exist.
     * This functions checks if the called plugin is active one.
     * When yes it is calling the standard method to create the tables
     *
     */
    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id)
    {

        return $this->onStoreInstallPluginTable($jplugin_id);
    }

    /**
     * This event is fired after the payment method has been selected. It can be used to store
     * additional payment info in the cart.
     *
     *
     * @param VirtueMartCart $cart : the actual cart
     * @return null if the payment was not selected, true if the data is valid, error message if the data is not valid
     *
     */
    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart, &$msg)
    {
        $valid = $this->OnSelectCheck($cart);
        return $valid;
    }

    /**
     * List payment methods selection
     * This method add html for a list of payments
     * This event is fired to display the pluginmethods in the cart (edit shipment/payment) for example
     *
     * @param VirtueMartCart $cart
     * @param int $selected
     * @param array $htmlIn
     * @return  True on success, false on failures, null when this plugin was not selected. On errors, JError::raiseWarning (or JError::raiseError) must be used to set a message.
     */
    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
    {
        return $this->displayListFE($cart, $selected, $htmlIn);
    }

    /**
     * return html for list
     *
     * @param type $plugin
     * @param type $selectedPlugin
     * @param type $pluginSalesPrice
     * @return string
     */
    // mozne zobrazenie obrazkov a pod.
    protected function unusedgetPluginHtml($plugin, $selectedPlugin, $pluginSalesPrice)
    {
        if (!class_exists('VirtueMartCart')) {
            require(VMPATH_SITE . DS . 'helpers' . DS . 'cart.php');
        }

        if (!class_exists('VirtueMartModelOrders')) {
            require(VMPATH_ADMIN . DS . 'models' . DS . 'orders.php');
        }

        $html = parent::getPluginHtml($plugin, $selectedPlugin, $pluginSalesPrice);

        if ($html) {

            $cart = VirtueMartCart::getCart();
            $orderId = $cart->virtuemart_order_id;
            $order = VirtueMartModelOrders::getOrder($orderId);

            $amnt = 0 + $order['details']['BT']->order_total;
            $amnt = number_format($amnt, 2, '.', '');

            $ruOk = (JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id));
            $ruFail = (JROUTE::_(JURI::root() . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginUserPaymentCancel&po='));
            $vs = str_pad($cart->virtuemart_order_id, 10, "0", STR_PAD_LEFT);
            $vubbtn_demo = $this->_currentMethod->vubbtn_demo;
            try {
                $vubbtn = new \VubEcard\VubEcard( trim($this->_currentMethod->vubbtn_cid), trim($this->_currentMethod->vubbtn_key), null, $vubbtn_demo );
                $vubbtn->setCallbackUrlSuccesfull($ruOk);
                $vubbtn->setCallbackUrlError($ruFail);
                $vubbtn->setOrderDetails($vs, 0 + $amnt);
                $html .= $vubbtn->generateForm('vubButton');

                $html .= "<script type=\"text/javascript\">
//<![CDATA[
jQuery().ready(function($) {
   \$('#checkoutForm').attr( 'action', '".$vubbtn->urlPaymentGate."');
});
//]]>
</script>";

            } catch (Exception $e) {
                vmInfo($e->getMessage());
                //clear title and text thank you ...
                vRequest::setVar('html', '');
                vRequest::setVar('display_title', false);

                return false;
            }
        }
        return $html;
    }


    /**
     * returns true if it is to appear in the list of payments
     *
     * @param VirtueMartCart $cart
     * @param int $method
     * @param array $cart_prices
     * @return boolean
     */
    protected function checkConditions($cart, $method, $cart_prices)
    {
        //TODO: kontrola ci sa ma zobrazit
        return true;
    }

    /*
     * plgVmonSelectedCalculatePricePayment
     * Calculate the price (value, tax_id) of the selected method
     * It is called by the calculator
     * This function does NOT to be reimplemented. If not reimplemented, then the default values from this function are taken.
     *
     * @cart: VirtueMartCart the current cart
     * @cart_prices: array the new cart prices
     * @return null if the method was not selected, false if the shiiping rate is not valid any more, true otherwise
     *
     *
     */

    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
    {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }

    /**
     * plgVmOnCheckAutomaticSelectedPayment
     * Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
     * The plugin must check first if it is the correct type
     *
     * @param VirtueMartCart cart: the cart object
     * @return null if no plugin was found, 0 if more then one plugin was found,  virtuemart_xxx_id if only one plugin is found
     *
     */
    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter)
    {
        $return = $this->onCheckAutomaticSelected($cart, $cart_prices);
        if (isset($return)) {
            return 0;
        } else {
            return null;
        }
    }

    /**
     * This method is fired when showing the order details in the frontend.
     * It displays the method-specific data.
     *
     * @param integer $order_id The order ID
     * @return mixed Null for methods that aren't active, text (HTML) otherwise
     */
    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name)
    {
        return $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }

    /**
     * This method is fired when showing the order details in the backend.
     * It displays the the payment method-specific data.
     * All plugins *must* reimplement this method.
     *
     * @param integer $_virtuemart_order_id The order ID
     * @param integer $method_id Payment method used for this order
     *
     * @return mixed Null when for payment methods that were not selected, text (HTML) otherwise
     */
    public function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id)
    {
        if (!$this->selectedThisByMethodId($virtuemart_paymentmethod_id)) {
            return NULL; // Another method was selected, do nothing
        }
        if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return NULL; // Another method was selected, do nothing
        }
        $db = JFactory::getDBO();
        $q = 'SELECT * FROM `' . $this->_tablename . '` WHERE ';
        $q .= ' `virtuemart_order_id` = ' . $virtuemart_order_id;

        $db->setQuery($q);
        if (!($paymentData = $db->loadObject())) {
            // JError::raiseWarning(500, $db->getErrorMsg());
        }
        $html = '<table class="adminlist table"  >' . "\n";
        $html .= $this->getHtmlHeaderBE();
        $html .= '     <tbody>' . "\n";
        $html .= $this->getHtmlRowBE('COM_VIRTUEMART_PAYMENT_NAME', $paymentData->payment_name);
        $html .= '     <tr>' . "\n";
        $html .= '		<td>' . vmText::_('VMPAYMENT_VUBBTN_RESULT') . '</td>' . "\n";
        $html .= '		<td>' . $paymentData->result . '</td>' . "\n";
        $html .= '     </tr>';
        if (\VubEcard\VubEcard::APPROVED_RESPONSE === $paymentData->result) {
            $html .= '     <tr>' . "\n";
            $html .= '		<td>' . vmText::_('VMPAYMENT_VUBBTN_VS') . '</td>' . "\n";
            $html .= '		<td>' . $paymentData->vs . '</td>' . "\n";
            $html .= '     </tr>';

            $html .= '     <tr>' . "\n";
            $html .= '		<td>' . vmText::_('VMPAYMENT_VUBBTN_BANK') . '</td>' . "\n";
            $html .= '		<td>' . 'VÚB Banka' . '</td>' . "\n";
            $html .= '     </tr>';

            $html .= '     <tr>' . "\n";
            $html .= '		<td>' . vmText::_('VMPAYMENT_VUBBTN_DATE') . '</td>' . "\n";
            $html .= '		<td>' . $paymentData->payment_date . '</td>' . "\n";
            $html .= '     </tr>';
        }
        $html .= '     </tbody>' . "\n";
        $html .= '</table>' . "\n";

        return $html;
    }

    // This method is fired when showing when priting an Order
    // It displays the the payment method-specific data.
    function plgVmonShowOrderPrintPayment($order_number, $method_id)
    {
        return $this->onShowOrderPrint($order_number, $method_id);
    }

    function plgVmDeclarePluginParamsPaymentVM3(&$data)
    {
        return $this->declarePluginParams('payment', $data);
    }

    /* compatibility joomle 2.5, virtuemart 2.0 */
    function plgVmDeclarePluginParamsPayment($name, $id, &$data)
    {
        return $this->declarePluginParams('payment', $name, $id, $data);
    }

    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table)
    {
        return $this->setOnTablePluginParams($name, $id, $table);
    }

    /**
     * render plugin name + bank
     *
     * @param type $plugin
     * @return string
     */
    protected function renderPluginName($plugin)
    {
        return vmText::_('VMPAYMENT_VUBBTN');
    }

    protected function generatePostString($vubbtn)
    {
        $postString = '';
        $postString .= 'encoding=utf-8';
        $postString .= '&clientId='.$vubbtn->getClientId();
        $postString .= '&amount='.$vubbtn->orderAmount;
        $postString .= '&oid='.$vubbtn->orderId;
        $postString .= '&okurl='.urlencode($vubbtn->callbackUrlSuccesfull);
        $postString .= '&failUrl='.urlencode($vubbtn->callbackUrlError);
        $postString .= '&trantype='.$vubbtn->configTransactionType;
        $postString .= '&instalment='.$vubbtn->installment;
        $postString .= '&MERCHANTSAFEAUTHTYPE='.$vubbtn->msAuthType;
        $postString .= '&MERCHANTSAFEKEY='.$vubbtn->msKey;
        $postString .= '&currency='.$vubbtn->currency;
        $postString .= '&rnd='.urlencode($vubbtn->rnd);
        //$postString .= '&hash='.urlencode($vubbtn->getHash() . 'test');
        $postString .= '&hash='.urlencode($vubbtn->getHash());
        $postString .= '&storetype='.$vubbtn->storeType;
        $postString .= '&hashAlgorithm='.$vubbtn->hashAlgorithm;
        $postString .= '&lang='.$vubbtn->configLanguage;
        $postString .= '&paymentGate='.urlencode($vubbtn->urlPaymentGate);

        return $postString;
    }
}