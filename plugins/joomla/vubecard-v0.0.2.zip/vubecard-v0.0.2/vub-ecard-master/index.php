<hr />
<h2>vygenerovany button</h2>
<!-- <p>zivy button, klikni. Presne takto sa ma spravat aj plugin.</p> -->
<?php
    /* INCLUDNUTIE NASEJ KNIZNICE. IMPLEMENTUJE TO PSR 4, TO ZNAMNEA ZE FUNGUJE
       AUTOLOADING NA ZAKLADE NAMESPACOV. VY NERIESITE NIC, IBA TENTO INCLUDE */
    require_once(/* CESTA K NASEJ KNIZNICI */ 'lib/autoload.php');

    /* INICIALIZACIA OBJEKTU, VSTUPNE HODNOTY BY MALI BYT HODNOTY ZO SETTINGOV V
       JOOMLA A MAGENTO */

    $vub = new VubEcard\VubEcard(10000001 /* ID */, Kreslo123987 /* STORE KEY */, null, true /* SANDBOX */);
    // $vub = new VubEcard\VubEcard(10741501 /* ID */, KReslo123 /* STORE KEY */, null, true /* SANDBOX */);

    /* NAVRATOVE URL Z BANKY (NEVIEM CI DEFINUJE POUZIVATEL ALEBO MAGENTO, JOOMLA DEFINUJE SAMA) */
    $vub->setCallbackUrlSuccesfull('http://localhost/joomla/plugins/vmpayment/vubbtn/vub-ecard-master/ok.php' /* NAVRATOVA URL DO ESHOPU V PRIPADE OK PLATBY */);
    $vub->setCallbackUrlError('http://localhost/joomla/plugins/vmpayment/vubbtn/vub-ecard-master/nok.php' /* NAVRATOVA URL DO ESHOPU V PRIPADE CHYBNEJ PLATBY */);

    /* NASTAVENIE UDAJOV O OBJEDNAVKE */
    $vub->setOrderDetails(999 /* ID OBJENAVKY */, 1001 /* CELKOVA CENA OBJEDNAVKY */);

    /* VYGENERUJE DEMO BUTTON NA ODOSLANIE KLIENTA DO BANKY */
    echo $vub->generateForm('vubButton');
?>

<!-- <hr />
<h2>kod pouzity na generovanie buttonu</h2>
<p>Na vygenerovanie buttonu vyssie je potrebny tento kod. V podstate, toto ma byt obsahom magento a joomla pluginu. Povinne parametre pre vygeneroanie buttonu su id, store id, id objednavky, suma a callback urls</p>
<img src="./code.png" /> -->
