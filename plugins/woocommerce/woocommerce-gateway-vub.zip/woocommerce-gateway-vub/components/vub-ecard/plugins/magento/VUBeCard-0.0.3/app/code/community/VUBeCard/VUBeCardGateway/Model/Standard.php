<?php

class VUBeCard_VUBeCardGateway_Model_Standard extends Mage_Payment_Model_Method_Abstract {

    protected $_code = 'vubecardgateway';
    protected $_isInitializeNeeded = true;
    protected $_canUseInternal = true;
    protected $_canUseForMultishipping  = false;
    protected $_canUseCheckout          = true;
    //template choice banks
    protected $_formBlockType = 'vubecardgateway/checkout_form';
    protected $_paymentMethod = 'checkout';

    public function getOrderPlaceRedirectUrl() {
        return Mage::getUrl('vubecardgateway/payment/redirect', array('_secure' => true));
    }
}
