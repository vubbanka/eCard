<?php

/*
 * VUBeCardGateway Payment Controller
 *
 */

$ExternalLibPath = Mage::getModuleDir('', 'VUBeCard_VUBeCardGateway') . DS . 'Helper' . DS . 'lib' . DS . 'vub-ecard-master' . DS . 'lib' . DS . 'autoload.php';
require_once ($ExternalLibPath);

class VUBeCard_VUBeCardGateway_PaymentController extends Mage_Core_Controller_Front_Action {

    // The redirect action is triggered when someone places an order
    public function redirectAction()
    {
        //load order
        $order = new Mage_Sales_Model_Order();
        $order_id = Mage::getSingleton('checkout/session')->getLastRealOrderId();
        $order->loadByIncrementId($order_id);

        //load config data
        $config = Mage::getStoreConfig('payment/vubecardgateway');

        $vubecard_demo = ($config['demo'] == '1') ? true : false;

        $cid = $config['cid'];
        $key = $config['key'];

        $error = '';

        $amnt = $order->getBaseGrandTotal();
        $vs = str_pad($order_id, 10, "0", STR_PAD_LEFT);
        $ruOk = Mage::getUrl('vubecardgateway/payment/response', array('_secure' => true));
        $ruKo = Mage::getUrl('vubecardgateway/payment/failure', array('_secure' => true));

        $postParameters = array();

        try {
            $vubbtn = new \VubEcard\VubEcard(trim($cid), trim($key), null, $vubecard_demo);

            // error: TLS 1.0/1.1 is not supported
            //if($vubbtn->validateCredentials()) {
                $vubbtn->setCallbackUrlSuccesfull($ruOk);
                $vubbtn->setCallbackUrlError($ruKo);
                $vubbtn->setOrderDetails($vs, 0 + $amnt);

                $gatewayUrl = $vubbtn->urlPaymentGate;

                $postParameters['vubbtn'] = $vubbtn;

                $this->loadLayout();
                $block = $this->getLayout()
                    ->createBlock('Mage_Core_Block_Template', 'vubecardgateway', array('template' => 'vubecardgateway/redirect.phtml'))
                    ->setData(array('error' => $error, 'url' => $gatewayUrl));
                $block->postParameters = $postParameters;
                $this->getLayout()->getBlock('content')->append($block);
                $this->renderLayout();

                return;
            /*
            } else {
                $error = 'Invalid credentials';
            }
            */
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        $order->cancel()->setState(Mage_Sales_Model_Order::STATE_CANCELED, true, $error)->save();
        Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/failure', array('_secure' => true));
    }

    // The failure action is triggered when your gateway sends back a failure after processing the customer's payment
    public function failureAction() {
        $responseParams = $this->getRequest()->getParams();

        //load order
        $order = new Mage_Sales_Model_Order();
        $order_id = Mage::getSingleton('checkout/session')->getLastRealOrderId();
        if($order_id) {
            $order->loadByIncrementId($order_id);

            $error = $this->getErrorMsg($responseParams);

            // we've got failure response from bank
            $order->cancel()->setState(Mage_Sales_Model_Order::STATE_CANCELED, true, 'Gateway has declined the payment. ' . $error)->save();
            Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/failure', array('_secure' => true));
        }
    }


    // The response action is triggered when your gateway sends back a response after processing the customer's payment
    public function responseAction() {
        $responseParams = $this->getRequest()->getParams();

        //load order
        $order = new Mage_Sales_Model_Order();
        $order_id = Mage::getSingleton('checkout/session')->getLastRealOrderId();
        $order->loadByIncrementId($order_id);

        //load config data
        $config = Mage::getStoreConfig('payment/vubecardgateway');
        $vubecard_demo = $config['demo'] == '1' ? true : false;
        $cid = $config['cid']; 
        $key = $config['key'];

        $error = '';
        $amnt = $order->getBaseGrandTotal();
        $vs = str_pad($order_id, 10, "0", STR_PAD_LEFT);

        $vubbtn = new \VubEcard\VubEcard( trim($cid), trim($key), null, $vubecard_demo );
        $vubbtn->setOrderDetails($vs, 0 + $amnt);

        if ($vubbtn->validateResponse($responseParams)) {
            //result OK
            $order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true, 'Gateway has authorized the payment.');
            $order->sendNewOrderEmail();
            $order->setEmailSent(true);
            $order->save();

            Mage::getSingleton('checkout/session')->unsQuoteId();
            Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/success', array('_secure' => true));
            return;
        } else {
            $error = $this->getErrorMsg($responseParams);
        }

        if ($error) {
            // There is a problem in the response we got
            $order->cancel()->setState(Mage_Sales_Model_Order::STATE_CANCELED, true, $error)->save();
            Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/failure', array('_secure' => true));
        } else {
            Mage_Core_Controller_Varien_Action::_redirect('');
        }
    }

    // The cancel action is triggered when an order is to be cancelled
    public function cancelAction() {
        if (Mage::getSingleton('checkout/session')->getLastRealOrderId()) {
            $order = Mage::getModel('sales/order')->loadByIncrementId(Mage::getSingleton('checkout/session')->getLastRealOrderId());
            if ($order->getId()) {
                // Flag the order as 'cancelled' and save it
                $order->cancel()->setState(Mage_Sales_Model_Order::STATE_CANCELED, true, 'Gateway has declined the payment.')->save();
            }
        }
    }

    // because VUB returns ... what VUB returns
    protected function getErrorMsg($postValues) {
        $retError = $this->__('Unknown server response');
        if(isset($postValues['ErrMsg'])) {
            $retError = $postValues['ErrMsg'];
        }
        if(isset($postValues['mdErrorMsg'])) {
            $retError = $postValues['mdErrorMsg'];
        }
        return $retError;
    }
}