<?php

class VUBeCard {

    //config parametrs
    const PARAM_VUBECARD_URL = 'PARAM_VUBECARD_URL';
    const PARAM_DEMO_MODE = 'DEMO';
    const PARAM_CID = 'CID';
    const PARAM_KEY = 'KEY';
    const PARAM_VS = 'VS';
    const PARAM_TYPE = 'TYPE'; //or BIC/SWIFT
    const PARAM_CURR = 'CURR';
    const PARAM_RUOK = 'RUOK';
    const PARAM_RUKO = 'RUKO';
    const PARAM_AMNT = 'AMNT';
    const PARAM_RESULT = 'RESULT';

    //response
    const RESULT_OK = 'OK';
    const RESULT_FAIL = 'RESULT_FAIL';
    
    //currency
    const CURR_EURO = 978;

    /**
     * Unique VUBeCard customer ID. Required.
     * @var String
     */
    protected $CID;

    /**
     * Private key to crypt communication. Required.
     * @var String
     */
    protected $KEY;

    /**
     * VUBeCard url.
     * @var String
     */
    protected $VUBECARD_URL;

    /**
     * VUBeCard payments gateways generator url.
     * @var String
     */
    protected $VUBECARD_PAYMENTS_GATEWAYS_GENERATOR_URL;

    /**
     * Amount. Max 13+2 numbers. Decimal point ".". Required.
     * @var Float
     */
    protected $AMNT;

    /**
     * Variable symbol. Max 10 numbers. Required.
     * @var String
     */
    protected $VS;

    /**
     * Payment type TYPE
     * @var String
     */
    protected $TYPE;

    /**
     * Currency code
     * @var Int[3]
     */
    protected $CURR;

    public function __construct($cfg = array()) {
        
        if (!array_key_exists(self::PARAM_VUBECARD_URL, $cfg) || array_key_exists(self::PARAM_DEMO_MODE, $cfg)) {
            $cfg[self::PARAM_VUBECARD_URL] = $cfg[self::PARAM_DEMO_MODE]
                    ? self::VUBECARD_URL_TEST : self::VUBECARD_URL;
        }
        if (empty($cfg[self::PARAM_CID]) || empty($cfg[self::PARAM_KEY]) || empty($cfg[self::PARAM_VUBECARD_URL])) {
            throw new Exception('Set variables in config file.' /* .  print_r($cfg, true) */);
        }

        $this->CID = $cfg[self::PARAM_CID];
        $this->VUBECARD_URL = $cfg[self::PARAM_VUBECARD_URL];
        $this->KEY = $cfg[self::PARAM_KEY];
    }

    /**
     * Get amount.
     * @return string
     */
    public function getAmnt() {
        return $this->AMNT;
    }

    /**
     * Set amount.
     * @param string $amnt
     * @return VUBeCard
     */
    public function setAmnt($AMNT) {
        $this->AMNT = $this->sanitizeAmnt($AMNT);
        return $this;
    }

    /**
     * Get currency.
     * @return string
     */
    public function getCurr() {
        return $this->CURR;
    }

    /**
     * Set currency.
     * @param string $curr
     * @return VUBeCard
     */
    public function setCurr($CURR) {
        $this->CURR = $CURR;
        return $this;
    }

    /**
     * Get variable symbol.
     * @return string
     */
    public function getVs() {
        return $this->VS;
    }

    /**
     * Set variable symbol.
     * @param string $vs
     * @return VUBeCard
     */
    public function setVs($VS) {
        $this->VS = $VS;
        return $this;
    }

    protected function sanitizeAmnt($AMNT) {

        return str_replace(',', '.', sprintf('%.2f', $AMNT));
    }

}

class VUBeCardRequest extends VUBeCard {

    /**
     * Return url. Required
     * @var String
     */
    protected $RU;

    /**
     * Customer e-mail. REQUIRED.
     * @var String
     */
    protected $EMAIL;

    /**
     * @return VUBeCard
     */
    public function __construct($options = array(), $cfgPath = '') {

        parent::__construct($options, $cfgPath);

        if (!isset($options[self::PARAM_AMNT])) {
            throw new Exception('Amount is not defined.');
        }
        if (empty($options[self::PARAM_AMNT])) {
            throw new Exception('Amount is empty.');
        }
        if (!is_int($options[self::PARAM_AMNT]) && !is_float($options[self::PARAM_AMNT])) {
            throw new Exception('Amount is not a number.');
        }
        if (preg_match("/^\d+(\.\d{1,2})?$/", $options[self::PARAM_AMNT]) == 0) {
            throw new Exception('Amount format is not valid.');
        }
        if (!isset($options[self::PARAM_CURR])) {
            throw new Exception('Currency is not defined.');
        }
        if (empty($options[self::PARAM_CURR])) {
            throw new Exception('Currency is empty.');
        }
        if (!isset($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is not defined.');
        }
        if (empty($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is empty.');
        }
        if (!is_numeric($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is not numeric.');
        }
        if (strlen($options[self::PARAM_VS]) > 10) {
            throw new Exception('VariableSymbol max length is 10.');
        }
        if (!isset($options[self::PARAM_RU])) {
            throw new Exception('ReturnUrl is not defined.');
        }
        if (empty($options[self::PARAM_RU])) {
            throw new Exception('ReturnUrl is empty.');
        }
        if (!isset($options[self::PARAM_CURR])) {
            throw new Exception('Currency is not defined.');
        }
        if (empty($options[self::PARAM_CURR])) {
            throw new Exception('Currency is empty.');
        }
        $this->setAmnt($options[self::PARAM_AMNT]);
        $this->setCurr($options[self::PARAM_CURR]);
        $this->setVs($options[self::PARAM_VS]);
        $this->setRu($options[self::PARAM_RUOK]);

        return $this;
    }

    /**
     * Return return url.
     * @return string
     */
    public function getRuOk() {

        return $this->RUOK;
    }

    /**
     * Set return url.
     * @param string $returnUrl
     * @return VUBeCard
     */
    public function setRuOk($RUOK) {

        $this->RUOK = $RUOK;
        return $this;
    }

    /**
     * Return return url.
     * @return string
     */
    public function getRuKo() {

        return $this->RUKO;
    }

    /**
     * Set return url.
     * @param string $returnUrl
     * @return VUBeCard
     */
    public function setRuKo($RUKO) {

        $this->RUKO = $RUKO;
        return $this;
    }

    /**
     * Get customer email.
     * @return String
     */
    public function getEmail()
    {
        return $this->EMAIL;
    }

    /**
     * Set customer email
     * @param String $EMAIL
     * return VUBeCard
     */
    public function setEmail($EMAIL)
    {
        $this->EMAIL = $EMAIL;
        return $this;
    }

    public function getUrl() {

        $params = array(
            'cid=' . $this->CID,
            'amnt=' . $this->AMNT,
            'curr=' . $this->CURR,
            'vs=' . $this->VS,
            'ruOk=' . urlencode($this->RUOK),
            'ruKo=' . urlencode($this->RUKO)
        );

        $url = $this->VUBECARD_URL . '?' . implode('&', $params);
        return $url;
    }

    public function getGeneratorUrl() {

        $params = array(
            'cid=' . $this->CID,
            'amnt=' . $this->AMNT,
            'curr=' . $this->CURR,
            'vs=' . $this->VS,
            'ruOk=' . urlencode($this->RU),
            'ruKo=' . urlencode($this->RU)
        );

        $url = $this->VUBECARD_PAYMENTS_GATEWAYS_GENERATOR_URL . '?' . implode('&', $params);
        return $url;
    }

    /**
     * Return string for hash to sign.
     * @var String
     */
    public function getString($type = true) {

        $string = $this->CID . ($type ? $this->TYPE : '') . $this->AMNT . $this->CURR . $this->VS . $this->RU;

        return $string;
    }

}

class VUBeCardResponse extends VUBeCard {

    /**
     * Status. Required
     * @var String
     */
    protected $RESULT;

    /**
     * Sign from besteron.
     * @var String
     */
    protected $SIGN;

    /**
     * @return VUBeCard
     */
    public function __construct($options = array(), $cfgPath = '') {

        parent::__construct($options, $cfgPath);

        if (!isset($options[self::PARAM_TYPE])) {
            throw new Exception('TYPE is not defined.');
        }
        if (empty($options[self::PARAM_TYPE])) {
            throw new Exception('TYPE code is empty.');
        }
        if (!isset($options[self::PARAM_AMNT])) {
            throw new Exception('Amount is not defined.');
        }
        if (empty($options[self::PARAM_AMNT])) {
            throw new Exception('Amount is empty.');
        }
        if (!isset($options[self::PARAM_CURR])) {
            throw new Exception('Currency is not defined.');
        }
        if (empty($options[self::PARAM_CURR])) {
            throw new Exception('Currency is empty.');
        }
        if (!isset($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is not defined.');
        }
        if (!isset($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is empty.');
        }
        if (!is_numeric($options[self::PARAM_VS])) {
            throw new Exception('VariableSymbol is not numeric.');
        }
        if (strlen($options[self::PARAM_VS]) > 10) {
            throw new Exception('VariableSymbol max length is 10.');
        }
        if (!isset($options[self::PARAM_RESULT])) {
            throw new Exception('Result is not defined.');
        }
        if (empty($options[self::PARAM_RESULT])) {
            throw new Exception('Result is empty.');
        }

        $this->TYPE = $options[self::PARAM_TYPE];
        $this->AMNT = $options[self::PARAM_AMNT];
        $this->CURR = $options[self::PARAM_CURR];
        $this->VS = $options[self::PARAM_VS];
        $this->RESULT = $options[self::PARAM_RESULT];

        return $this;
    }

    /**
     * Get result
     * @return string
     */
    public function getResult() {
        return $this->RESULT;
    }

    /**
     * Set result.
     * @param string $result
     * @return string
     */
    public function setResult($RESULT) {
        $this->RESULT = $RESULT;
        return $this;
    }

    /**
     * Generate string for generetaSign();
     * @return string
     */
    public function getString() {

        $string = $this->CID . $this->TYPE . $this->AMNT . $this->CURR . $this->VS . $this->RESULT;
        return $string;
    }
}
