<?php

$ExternalLibPath = Mage::getModuleDir('', 'VUBeCard_VUBeCardGateway') . DS . 'Helper' . DS . 'lib' . DS . 'VUBeCardClass.php';
require_once ($ExternalLibPath);

class VUBeCard_VUBeCardGateway_Block_Checkout_Form extends Mage_Payment_Block_Form {

    protected function _construct() {
        parent::_construct();
    }

    /**
     * render banks icon after payment label
     * 
     * @return string
     */
    public function getMethodLabelAfterHtml() {
        // $html = '<img style="float:right;display:inline;height:10px;vertical-align:middle;" src="'.$this->getSkinUrl('images/vubecardgateway/vub/4.png') . '" alt="VUBeCard" />';
        // return $html;
        return '';
    }

}
