<?php
namespace VubEcard\helpers;

class VubEcardLanguage extends \VubEcard\helpers\VubEcardHelper
{
  private static $defaultValues = ['sk', 'en'];

  public static function getDefaultValue() {
    return self::$defaultValues[0];
  }

}
