<?php
namespace VubEcard\helpers;

class HtmlHelper
{

    public static function inputHidden($htmlAttributes = [])
    {
        return self::input(array_merge($htmlAttributes, ['type' => 'hidden']));
    }

    public static function input($htmlAttributes = [])
    {
        return '<input ' . self::concatHtmlAttributes($htmlAttributes) . ' />';
    }

    public static function formOpen($htmlAttributes)
    {
        return self::tagOpen('form', $htmlAttributes);
    }

    public static function formClose()
    {
        return self::tagClose('form');
    }

    public static function tagOpen($tagName, $htmlAttributes = []) 
    {
        return '<' . $tagName . ' ' . self::concatHtmlAttributes($htmlAttributes) . '>';
    }

    public static function tagClose($tagName) 
    {
        return '</' . $tagName . '>';
    }    

    private static function concatHtmlAttributes($htmlAttributes = [])
    {
      if (!is_array($htmlAttributes)) {
        throw new VubException('HtmlAttributes have to be associative array [atttributeName => attributeValue]', 500);
      }

      $htmlAttributesString = [];
      foreach ($htmlAttributes as $attributeName => $attributeValue) {

        $htmlAttributesString[] = $attributeName . '="' . $attributeValue . '"';
      }

      return implode(' ', $htmlAttributesString);
    }    

}
