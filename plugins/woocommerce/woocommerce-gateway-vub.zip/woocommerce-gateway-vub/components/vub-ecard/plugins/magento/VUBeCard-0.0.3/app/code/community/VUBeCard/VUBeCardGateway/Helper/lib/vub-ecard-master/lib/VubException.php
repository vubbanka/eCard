<?php
namespace VubEcard;

use VubEcard\VubLog;

class VubException extends \Exception
{

  public function __construct($message, $code = 0, Exception $previous = null) {

      VubLog::writeError($message);

      parent::__construct($message, $code, $previous);
  }
}
