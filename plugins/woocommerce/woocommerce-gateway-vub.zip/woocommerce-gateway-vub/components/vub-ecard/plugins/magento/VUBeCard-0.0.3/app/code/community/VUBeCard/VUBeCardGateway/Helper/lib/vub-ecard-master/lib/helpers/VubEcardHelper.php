<?php
namespace VubEcard\helpers;

abstract class VubEcardHelper
{
    private static $data = [];

    abstract public static function getDefaultValue();

    public static function isAllowed($value)
    {
      $class = get_called_class();
      return in_array($value, $class::$data);
    }

    public function __get($name)
    {
        $class = get_called_class();

        if (array_key_exists($name, $class::$data)) {
            return $class::$data[$name];
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE);

        return null;
    }

    public function __isset($name)
    {
        $class = get_called_class();
        return isset($class::$data[$name]);
    }

    public function __unset($name)
    {
        $class = get_called_class();
        unset($class::$data[$name]);
    }
}
