<?php
namespace VubEcard;

class VubLog
{
  private $pathLogs = '';

  const LOG_TYPE_ERROR    = 0;
  const LOG_TYPE_WARNING  = 1;
  const LOG_TYPE_NOTICE   = 2;

  const FILE_ERROR    = 'vub-error.log';
  const FILE_WARNING  = 'vub-warning.log';
  const FILE_NOTICE   = 'vub-notice.log';

  public static function write($type, $message)
  {
    $message = self::alterMessage($type, $message);

    if (!file_exists(self::getFile($type))) {

      return file_put_contents(self::getFile($type), $message);
    } else {

      return file_put_contents(self::getFile($type), $message, FILE_APPEND | LOCK_EX);
    }
  }

  private static function getTypeName($type)
  {
    switch ($type) {

      case self::LOG_TYPE_ERROR:

        return 'ERROR';
        break;

      case self::LOG_TYPE_WARNING:

        return 'WARNING';
        break;

      case self::LOG_TYPE_NOTICE:

        return 'NOTICE';
        break;

      default:

        return 'N/A';
        break;
    }
  }

  private static function alterMessage($type, $message) {
    return self::getMessagePrefix($type) . $message . self::getMessageSuffix();
  }

  private static function getMessagePrefix($type)
  {
    return @date('Y-m-d H:i:s') . ' - ' . self::getTypeName($type) . ': ' . PHP_EOL;
  }

  private static function getMessageSuffix()
  {
    return PHP_EOL . '---------------------' . PHP_EOL;
  }

  public static function writeError($message)
  {
    return self::write(self::LOG_TYPE_ERROR, $message);
  }

  public static function writeWarning($message)
  {
    return self::write(self::LOG_TYPE_WARNING, $message);
  }

  public static function writeNotice($message)
  {
    return self::write(self::LOG_TYPE_NOTICE, $message);
  }

  private static function getFile($type = 1)
  {

    $path = __DIR__ . '/../logs/';

    switch ($type) {

      case self::LOG_TYPE_ERROR:

        $path .= self::FILE_ERROR;
        break;

      case self::LOG_TYPE_WARNING:

        $path .= self::FILE_WARNING;
        break;

      case self::LOG_TYPE_NOTICE:

        $path .= self::FILE_NOTICE;
        break;

      default:

        throw new VubException('Undefined error type', 500);
        break;
    }

    return $path;
  }
}
