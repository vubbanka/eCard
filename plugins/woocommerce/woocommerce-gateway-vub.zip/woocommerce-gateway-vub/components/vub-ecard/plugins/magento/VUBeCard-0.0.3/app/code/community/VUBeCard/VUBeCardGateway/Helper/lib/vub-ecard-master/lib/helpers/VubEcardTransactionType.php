<?php
namespace VubEcard\helpers;

class VubEcardTransactionType extends \VubEcard\helpers\VubEcardHelper
{
  private static $defaultValues = ['Auth', 'PreAuth'];

  public static function getDefaultValue() {
    return self::$defaultValues[0];
  }

}
