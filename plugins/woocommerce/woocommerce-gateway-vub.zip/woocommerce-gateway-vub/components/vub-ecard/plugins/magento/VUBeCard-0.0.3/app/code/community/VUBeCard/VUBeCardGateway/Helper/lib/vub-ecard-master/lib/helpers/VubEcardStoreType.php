<?php
namespace VubEcard\helpers;

class VubEcardStoreType extends \VubEcard\helpers\VubEcardHelper
{
  private static $defaultValues = ['pay_hosting', '3d_pay', '3d', '3d_pay_hosting'];

  public static function getDefaultValue() {
    return '3d_pay_hosting';
  }
}
