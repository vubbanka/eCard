<?php
    /**
     * Your Twitter App Info
     */

    // Consumer Key
    define('CONSUMER_KEY', 'AjwBVb90WAGbISSYRAJ8YeKRQ');
    define('CONSUMER_SECRET', 'n99JwEHAVvEi0X9rYR5Y543Q6cOgARlLrpHCvI2RCnZmKLnk9m');

    // User Access Token
    define('ACCESS_TOKEN', '3315255449-gCxaEz73licStYEfieyvgPPs1XXGRM1esnIcU9t');
    define('ACCESS_SECRET', 'aZ1wrmlYhA8KPpMiGlme2VVsMGM0bWNJcbcRs7MLwjrOo');

	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));