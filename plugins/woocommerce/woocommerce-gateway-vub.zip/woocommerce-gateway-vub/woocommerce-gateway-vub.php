<?php
/**
 * Plugin Name: WooCommerce Gateway VUB
 * Plugin URI: 
 * Description: Custom gateway for payments via VUB bank
 * Author: For Best Clients s.r.o
 * Author URI: https://www.forbestclients.com
 * Version: 1.0.2
 * Text Domain: 
 * Domain Path: 
 *
 *
 * @package   WC-Gateway-Vub
 * @author    For Best Clients s.r.o
 * @category  Admin
 * @copyright Copyright (c) 2021, For Best Clients s.r.o and WooCommerce
 *
 * This payment method create request to VUB bank to pay for order
 */
 
defined( 'ABSPATH' ) or exit;
define( 'WC_VUB_PAYMENT_PATH', plugin_dir_path( __FILE__ ) );


// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}


/**
 * Add the gateway to WC Available Gateways
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + vub gateway
 */
function wc_gateway_vub_add_to_gateways( $gateways ) {
	$gateways[] = 'WC_Gateway_VUB';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_gateway_vub_add_to_gateways' );


/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_gateway_vub_plugin_links( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=vub_gateway' ) . '">' . __( 'Configure', 'wc-gateway-vub' ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_gateway_vub_plugin_links' );

function wc_gateway_vub_form_submit() {
?>
    <script type="text/javascript">
        (function() {
            var form = document.getElementById('woocommerce-gateway-vub-form');
            if (form) {
                form.submit();
            }
        })()
    </script>
<?php
}


/**
 * VUB Payment Gateway
 *
 * Provides an VUB Payment Gateway for card payments in woocommerce
 *
 * @class 		WC_Gateway_VUB
 * @extends		WC_Payment_Gateway
 * @version		1.0.2
 * @package		WooCommerce/Classes/Payment
 * @author 		For Best Clients s.r.o
 */
add_action( 'plugins_loaded', 'wc_gateway_vub_gateway_init', 11 );

function wc_gateway_vub_gateway_init() {

	class WC_Gateway_VUB extends WC_Payment_Gateway {

		/**
		 * ClientId received from VUB
		 * @var string
		 */
		private $clientId = false;

		/**
		 * Key received from VUB
		 * @var string
		 */
		private $storeKey = false;

		/**
		 * Message to show when payment was OK
		 * @var string
		 */
		private $successMessage = false;

		/**
		 * Message to show when payment failed
		 * @var string
		 */
		private $failedMessage = false;

		/**
		 * Message to show when order is cancelled
		 * @var string
		 */
		private $cancelledMessage = false;

		/**
		 * Use testing environment
		 * @var string
		 */
		private $useTest = false;


		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {

			require_once(WC_VUB_PAYMENT_PATH.'components/vub-ecard/lib/autoload.php');
	  
			$this->id                 = 'vub_gateway';
			$this->has_fields         = false;
			$this->method_title       = __( 'VUB card payment', 'wc-gateway-vub' );
			$this->method_description = __( 'Allow card payments via VUB bank.', 'wc-gateway-vub' );
		  
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
		  
			// Define user set variables
			$this->title        = $this->get_option( 'title' );
			$this->description  = $this->get_option( 'description' );
			$this->instructions = $this->get_option( 'instructions', $this->description );
			$this->clientId 	= $this->get_option( 'clientId');
			$this->storeKey 	= $this->get_option( 'storeKey');
			$this->successMessage = $this->get_option( 'successMessage' , __('Congratulations! Your order was successfully paid', 'wc-gateway-vub'));
			$this->failedMessage = $this->get_option( 'failedMessage' , __('Unfortunately your payment was not processed', 'wc-gateway-vub'));
			$this->cancelledMessage = $this->get_option( 'cancelledMessage' , __('Your order was cancelled, cannot provide payment', 'wc-gateway-vub'));
			$this->useTest = $this->get_option( 'useTest');
		  
			// Actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
			// add_action( 'woocommerce_api_' . $this->id , array( $this, 'webhook' ) );
			add_action( 'woocommerce_api_' . $this->id. '_success', array( $this, 'success' ) );
			add_action( 'woocommerce_api_' . $this->id. '_error', array( $this, 'error' ) );

			// echo plugin_dir_url( __FILE__ );

		}
	
	
		/**
		 * Initialize Gateway Settings Form Fields
		 */
		public function init_form_fields() {
	  
			$this->form_fields = apply_filters( 'wc_gateway_vub_form_fields', array(
		  
				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-vub' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable VUB gateway', 'wc-gateway-vub' ),
					'default' => 'yes'
				),
				
				'title' => array(
					'title'       => __( 'Title', 'wc-gateway-vub' ),
					'type'        => 'text',
					'description' => __( 'Add title of payment which will be visible on checkout page', 'wc-gateway-vub' ),
					'default'     => __( 'VUB payment', 'wc-gateway-vub' ),
					'desc_tip'    => true,
				),
				
				'description' => array(
					'title'       => __( 'Description', 'wc-gateway-vub' ),
					'type'        => 'textarea',
					'description' => __( 'Description of payment method visivle on checkout page', 'wc-gateway-vub' ),
					'default'     => __( 'Choose this option if you want to pay order via credit/debet card.', 'wc-gateway-vub' ),
					'desc_tip'    => true,
				),
				
				'instructions' => array(
					'title'       => __( 'Instructions', 'wc-gateway-vub' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that will be added to the thank you page when order is in pending.', 'wc-gateway-vub' ),
					'default'     => '',
					'desc_tip'    => true,
				),
				
				'successMessage' => array(
					'title'       => __( 'Success message', 'wc-gateway-vub' ),
					'type'        => 'textarea',
					'description' => __( 'Success message to be shown when payment was ok.', 'wc-gateway-vub' ),
					'default'     => __('Congratulations! Your order was successfully paid', 'wc-gateway-vub'),
					'desc_tip'    => true,
				),
				
				'failedMessage' => array(
					'title'       => __( 'Failed message', 'wc-gateway-vub' ),
					'type'        => 'textarea',
					'description' => __( 'Message to be shown when payment failed.', 'wc-gateway-vub' ),
					'default'     => __('Unfortunately your payment was not processed', 'wc-gateway-vub'),
					'desc_tip'    => true,
				),
				
				'cancelledMessage' => array(
					'title'       => __( 'Cancelled message', 'wc-gateway-vub' ),
					'type'        => 'textarea',
					'description' => __( 'Message to be shown when order is in Cancelled status', 'wc-gateway-vub' ),
					'default'     => __('Your order was cancelled, cannot provide payment', 'wc-gateway-vub'),
					'desc_tip'    => true,
				),

				'clientId' => array(
					'title'       => __( 'Client ID', 'wc-gateway-vub' ),
					'type'        => 'text',
					'description' => __( 'Add your client ID received from bank.', 'wc-gateway-vub' ),
					'default'     => '',
					'desc_tip'    => false,
				),

				'storeKey' => array(
					'title'       => __( 'Store Key', 'wc-gateway-vub' ),
					'type'        => 'text',
					'description' => __( 'Add your Key received from bank.', 'wc-gateway-vub' ),
					'default'     => '',
					'desc_tip'    => false,
				),

				'useTest' => array(
					'title'   => __( 'Use test', 'wc-gateway-vub' ),
					'type'    => 'checkbox',
					'label'   => __( 'Use testing environment', 'wc-gateway-vub' ),
					'default' => 'no'
				),

			) );
		}
	
		/**
		 * Output for the order received page
		 * Generates button to process payment.
		 */
		public function thankyou_page($order_id) {

			$order = wc_get_order($order_id);
			
			switch($order->get_status()){

				case "pending" :

                    $locale = get_locale();
                    $langAlpha2 = explode('_', $locale)[0];

					$useTest = ($this->useTest == "no") ? false : true;
					$vub = new VubEcard\VubEcard($this->clientId, $this->storeKey, null, $useTest);
					$vub->setCallbackUrlSuccesfull(get_bloginfo('url').'/?wc-api=vub_gateway_success&order_id='.$order_id);
					$vub->setCallbackUrlError(get_bloginfo('url').'/?wc-api=vub_gateway_success&order_id='.$order_id);

					$vub->setOrderDetails($order_id, $order->get_total());
                    $vub->setLang($langAlpha2);

					if ( $this->instructions ) {
						echo wpautop( wptexturize( $this->instructions ) );
					}

					echo $vub->generateForm(
					  	[
							'tel' 	=> $order->get_billing_phone(),
							'email'	=> $order->get_billing_email()
						],
						[],
                        ['id' => "woocommerce-gateway-vub-form"],
						['value' => 'Prejsť k platbe', 'id' => 'VUBbutton', 'class' => 'wp-block-button__link wp-element-button']
					  );

                        add_action('wp_footer', 'wc_gateway_vub_form_submit');
					break;

				case "completed" : 

					if ( $this->successMessage ) {
						echo wpautop( wptexturize( $this->successMessage ) );
					}
					break;
					
				case "cancelled" : 

					if ( $this->cancelledMessage ) {
						echo wpautop( wptexturize( $this->cancelledMessage ) );
					}
					break;

				case "failed" : 

					if ( $this->failedMessage ) {
						echo wpautop( wptexturize( $this->failedMessage ) );
					}
					break;

			}

			
		}

		/**
		 * Success page for callback
		 * Handle order and set it as completed
		 */
		public function success() { 

			$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

			if(!$order_id){ return false; }

			$order = wc_get_order($order_id);
			if(!$order){ return false; }

			if($order->get_status() == 'cancelled'){
				return false;
			}

			$useTest = ($this->useTest == "no") ? false : true;
			$vub = new VubEcard\VubEcard($this->clientId, $this->storeKey, null, $useTest);
  			if($vub->validateResponse($_POST)){
  				$order->update_status( 'completed', __( 'Order successfully saved', 'wc-gateway-vub' ) );	
  			}else{
  				$order->update_status( 'failed', __( 'Order payment failed', 'wc-gateway-vub' ) );	
  			}

			wp_redirect($this->get_return_url( $order ));
			exit;
		}

		/**
		 * Set order to failed status
		 */
		public function error() { 
		  
		  	$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : null;

			if(!$order_id){ return false; }

			$order = wc_get_order($order_id);
			if(!$order){ return false; }

			$order->update_status( 'failed', __( 'Order payment failed', 'wc-gateway-vub' ) );	

			wp_redirect($this->get_return_url( $order ));
			exit;

		}
	
		/**
		 * Process the payment and return the result
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id ) {
	
			$order = wc_get_order( $order_id );
			
			// Mark as on-hold (we're awaiting the payment)
			$order->update_status( 'pending', __( 'Awaiting online payment', 'wc-gateway-vub' ) );
			
			// Reduce stock levels
			$order->reduce_order_stock();
			
			// Remove cart
			WC()->cart->empty_cart();
			
			// Return thankyou redirect
			return array(
				'result' 	=> 'success',
				'redirect'	=> $this->get_return_url( $order )
			);
		}
	
  }
}