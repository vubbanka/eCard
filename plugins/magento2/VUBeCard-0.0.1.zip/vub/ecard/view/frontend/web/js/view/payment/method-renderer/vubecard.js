/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/model/url-builder',
        'mage/url',
    ],
    function (Component, urlBuilder, url) {
        'use strict';

        return Component.extend({
            redirectAfterPlaceOrder: false,
            defaults: {
                template: 'VUB_ECard/payment/form',
            },

            initialize: function() {
                this._super();
                self = this;
            },

            getCode: function() {
                return 'vubecard';
            },

            getData: function() {
                return {
                    'method': this.item.method,
                };
            },
            afterPlaceOrder: function () {
                window.location.replace(url.build('vubecard/payment/redirect'));
            },
        });
    }
);
