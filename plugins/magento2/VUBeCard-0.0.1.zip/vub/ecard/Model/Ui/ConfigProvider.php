<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace VUB\ECard\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\App\Helper\Context;
use VUB\ECard\Gateway\Config\Config;

/**
 * Class ConfigProvider
 */
final class ConfigProvider implements ConfigProviderInterface
{
    protected $gatewayConfig;
    protected $scopeConfigInterface;

    public function __construct(
        Config $gatewayConfig,
        Context $context
    )
    {
        $this->gatewayConfig = $gatewayConfig;
        $this->scopeConfigInterface = $context->getScopeConfig();
    }


    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        return [
            'payment' => [
                Config::CODE => []
            ]
        ];
    }
}
