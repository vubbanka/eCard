## Installation
This module can be installed by copying unzipped package to `app/code` folder. You have to run `magento setup:upgrade` and `magento setup:di:compile` then. 

## Contributors
[For Best Clients s.r.o.](https://www.forbestclients.com/)
