<?php

namespace VUB\ECard\Gateway\Config;

/**
 * Class Config.
 * Values returned from Magento\Payment\Gateway\Config\Config.getValue()
 * are taken by default from ScopeInterface::SCOPE_STORE
 */
class Config extends \Magento\Payment\Gateway\Config\Config
{
    const CODE = 'vubecard';

    const KEY_ACTIVE = 'active';
    const KEY_CUSTOMER_ID = 'customer_id';
    const KEY_STORE_KEY = 'store_key';
    const KEY_IS_SANDBOX = 'sandbox';
    const KEY_SPECIFIC_COUNTRIES = 'specific_countries';

    /**
     * Get Merchant number
     *
     * @return string
     */
    public function getCustomerId() {
        return $this->getValue(self::KEY_CUSTOMER_ID);
    }

    /**
     * Get Merchant number
     *
     * @return string
     */
    public function getStoreKey() {
        return $this->getValue(self::KEY_STORE_KEY);
    }

    /**
     * Get Payment configuration statusF
     * @return bool
     */
    public function isActive()
    {
        return (bool) $this->getValue(self::KEY_ACTIVE);
    }

    /**
    * Get Payment configuration status
    * @return bool
    */
    public function isSandbox()
    {
        return (bool) $this->getValue(self::KEY_IS_SANDBOX);
    }

    /**
     * Get specific country
     *
     * @return string
     */
    public function getSpecificCountry()
    {
        return $this->getValue(self::KEY_SPECIFIC_COUNTRIES);
    }

}
