<?php
namespace VUB\ECard\Gateway\Http\Client;

use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;

class ClientMock implements ClientInterface
{

    /**
     * Places request to gateway.
     *
     * @param TransferInterface $transferObject
     * @return array
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        return [ 'IGNORED' => [ 'IGNORED' ] ];
    }
}
