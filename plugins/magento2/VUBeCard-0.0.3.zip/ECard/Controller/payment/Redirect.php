<?php

namespace VUB\ECard\Controller\Payment;

use Magento\Sales\Model\Order;

class Redirect extends \VUB\ECard\Controller\Checkout
{

    private function proceedToGateway(Order $order)
    {
//        $this->getHelper()->setHeaders();
        $gateway = $this->getHelper()->getPaymentGateway($order);
        if (!$gateway) {
            throw new \Exception(__('VUB eCard payment gateway not found'));
        }

        echo '<html><body>';
        echo __('redirecting to VUBeCard Gateway ...');

        echo $gateway->generateForm(
            'vubecard_form',
            [],
            ['id' => 'frm-vubecard'],
            ['style' => 'display: none;']
        );
        echo
        '<script>
                var form = document.getElementById("frm-vubecard");
                form.submit();
            </script>';
        echo '</body></html>';

    }

    public function execute()
    {
        $logger = $this->getLogger();
        try {

            $order = $this->getOrder();
            if (!$order) {
                throw new \Exception(__('Order not found'));
            }

            if ($order->getState() === Order::STATE_PENDING_PAYMENT) {
                $this->proceedToGateway($order);
                exit;
            } else if ($order->getState() === Order::STATE_CANCELED) {
                $errorMessage = $this->getCheckoutSession()->getVubecardErrorMessage();
                if ($errorMessage) {
                    $this->getMessageManager()->addWarningMessage($errorMessage);
                    $errorMessage = $this->getCheckoutSession()->unsVubecardErrorMessage();
                }
                $this->getCheckoutSession()->restoreQuote(); //restore cart
                $this->_redirect('checkout/cart');
            } else {
                $logger->debug('Order in unrecognized state: ' . $order->getState());
                $this->_redirect('checkout/cart');
            }
        } catch (\Exception $e) {
            $logger->debug('An exception was encountered in vubecard/payement/request: ' . $e->getMessage());
            $logger->debug($e->getTraceAsString());
            $this->getMessageManager()->addErrorMessage(__('Unable to start VUB eCard Checkout.'));
            $this->_redirect('/');
        }

    }
}
