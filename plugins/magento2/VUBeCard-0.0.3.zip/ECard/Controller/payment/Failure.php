<?php

namespace VUB\ECard\Controller\Payment;

use Magento\Sales\Model\Order;

class Failure extends \VUB\ECard\Controller\Checkout
{

    public function execute()
    {
        $orderId = $this->getRequest()->getParam('orderId');
        $order = $this->getOrderById($orderId);
        $returnUrl = $this->getHelper()->getUrl('checkout/onepage/failure');

        if ($order) {
            $responseParams = $this->getRequest()->getParams();
            if ($order->getStatus() == Order::STATE_PENDING_PAYMENT) {
                $this->cancelOrder($order, $this->getErrorMsg($responseParams));
            }

            $this->restoreSessionByOrder($order);
        }

        return $this->_redirect($returnUrl);
    }

}
