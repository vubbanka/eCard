<?php

namespace VUB\ECard\Controller;

use Magento\Framework\App\Action\Action;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\OrderFactory;
use VUB\ECard\Helper\Data;
use VUB\ECard\Gateway\Config\Config;
use Psr\Log\LoggerInterface;

use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

abstract class Checkout extends Action implements CsrfAwareActionInterface {

    const LOG_FILE = 'vubecard.log';

    private $_context;

    private $_checkoutSession;

    private $_orderFactory;

    private $_dataHelper;

    private $_gatewayConfig;

    private $_messageManager;

    private $_logger;

    public function __construct(
        Config $gatewayConfig,
        Session $checkoutSession,
        Context $context,
        OrderFactory $orderFactory,
        Data $dataHelper,
        LoggerInterface $logger) {
        parent::__construct($context);
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        $this->_dataHelper = $dataHelper;
        $this->_gatewayConfig = $gatewayConfig;
        $this->_messageManager = $context->getMessageManager();
        $this->_logger = $logger;
    }

    // because VUB returns ... what VUB returns
    protected function getErrorMsg($postValues) {
        $retError = __('Unknown server response');
        if(isset($postValues['ErrMsg'])) {
            $retError = $postValues['ErrMsg'];
        }
        if(isset($postValues['mdErrorMsg'])) {
            $retError = $postValues['mdErrorMsg'];
        }
        return $retError;
    }

    /**
     * @inheritDoc
     */
    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    protected function getContext() {
        return $this->_context;
    }

    protected function getCheckoutSession() {
        return $this->_checkoutSession;
    }

    protected function getOrderFactory() {
        return $this->_orderFactory;
    }

    protected function getHelper() {
        return $this->_dataHelper;
    }

    protected function getGatewayConfig() {
        return $this->_gatewayConfig;
    }

    protected function getMessageManager() {
        return $this->_messageManager;
    }

    protected function getLogger() {
        return $this->_logger;
    }

    protected function getOrder()
    {
        $orderId = $this->_checkoutSession->getLastRealOrderId();

        if (!isset($orderId)) {
            return null;
        }

        return $this->getOrderById($orderId);
    }

    protected function getOrderById($orderId)
    {
        $order = $this->_orderFactory->create()->loadByIncrementId($orderId);

        if (!$order->getId()) {
            return null;
        }

        return $order;
    }

    protected function getObjectManager()
    {
        return \Magento\Framework\App\ObjectManager::getInstance();
    }

    public function cancelOrder($order, $comment)
    {
        $this->_dataHelper->cancelOrder($order, $comment);
    }

    public function cancelCurrentOrder($comment)
    {
        $order = $this->getOrder();
        return $this->_dataHelper->cancelOrder($order, $comment);
    }

    public function restoreSessionByOrder($order)
    {

        $this->getCheckoutSession()->setLastRealOrderId($order->getIncrementId());
        $this->getCheckoutSession()->setLastOrderId($order->getId());
        $this->getCheckoutSession()->setLastQuoteId($order->getQuoteId());
        $this->getCheckoutSession()->setLastSuccessQuoteId($order->getQuoteId());
    }
}
