/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/* @api */
define([
    'Magento_Checkout/js/view/payment/default',
    'mage/url'
], function (Component, url) {
    'use strict';

        return Component.extend({
            redirectAfterPlaceOrder: false,
            defaults: {
                template: 'VUB_ECard/payment/form',
            },

            initialize: function() {
                this._super();
                self = this;
            },

            getCode: function() {
                return 'vubecard';
            },

            getData: function() {
                return {
                    'method': this.item.method,
                };
            },
            afterPlaceOrder: function () {
                window.location.replace(url.build('vubecard/payment/redirect'));
            },
        });
    }
);
