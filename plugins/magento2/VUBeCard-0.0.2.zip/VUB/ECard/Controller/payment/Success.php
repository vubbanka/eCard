<?php

namespace VUB\ECard\Controller\Payment;

use Magento\Sales\Model\Order;


class Success extends \VUB\ECard\Controller\Checkout
{

    public function execute()
    {
        $orderId = $this->getRequest()->getParam('orderId');
        $order = $this->getOrderById($orderId);
        $successReturnUrl = $this->getHelper()->getUrl('checkout/onepage/success');
        $failureReturnUrl = $this->getHelper()->getUrl('checkout/onepage/failure');

        if ($order) {
            $gateway = $this->getHelper()->getPaymentGateway($order);
            if (!$gateway) {
                throw new \Exception(__('VUB eCard payment gateway not found'));
            }
            $responseParams = $this->getRequest()->getParams();

            if ($gateway->validateResponse($responseParams)) {
                try {
                    $order->setState(Order::STATE_PROCESSING)
                        ->setStatus(Order::STATE_PROCESSING)
                        ->setEmailSent($this->getHelper()->sendOrderEmail($order))
                        ->save();

                    $order->addStatusToHistory(Order::STATE_PROCESSING, __("VUB eCard authorisation success. Transaction #%1", $responseParams['TRANID']));
                    $order->save();

                } catch (\Exception $e) {
                    echo $e->getMessage();
                    exit;
                }

                $this->getCheckoutSession()->unsQuoteId();
                $this->restoreSessionByOrder($order);
                return $this->_redirect($successReturnUrl);
            } else {
                $error = $this->getErrorMsg($responseParams);
            }

            if ($error) {
                // There is a problem in the response we got
                $order->cancel()->setState(Order::STATE_CANCELED)->save();
                $this->restoreSessionByOrder($order);
                return $this->_redirect($failureReturnUrl);
            } else {
                $this->restoreSessionByOrder($order);
                return $this->_redirect('');
            }
        }

        $this->restoreSessionByOrder($order);
        return $this->_redirect($successReturnUrl);
    }

}
