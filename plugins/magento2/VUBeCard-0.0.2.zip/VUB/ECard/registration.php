<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

require_once(__DIR__ . '/lib/vub-ecard-master/lib/autoload.php');

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'VUB_ECard',
    __DIR__
);
