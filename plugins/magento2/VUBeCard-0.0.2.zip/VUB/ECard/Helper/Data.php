<?php

namespace VUB\ECard\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Sales\Model\Order;
use VUB\ECard\Gateway\Config\Config;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Locale\ResolverInterface;
use Magento\Payment\Helper\Data as PaymentData;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\OrderManagementInterface;
use VubEcard\VubEcard;

/**
 * Provides helper methods for retrieving data for the vub ecard plugin
 */
class Data extends AbstractHelper {

    /**
     * @var VUB\ECard\Gateway\Config\Config
     */
    protected $_gatewayConfig;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;
    /**
     * @var \Magento\Payment\Helper\Data
     */
    protected $_paymentData;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;
    /**
     * @var \Magento\Framework\Locale\ResolverInterface
     */
    protected $_localeResolver;

    /**
     * @var OrderManagementInterface
     */
    protected $orderManagement;

    /**
     * @param VUB\ECard\Gateway\Config\Config $gatewayConfig
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager,
     * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
     */
    public function __construct(
        Config $gatewayConfig,
        ObjectManagerInterface $objectManager,
        Context $context,
        PaymentData $paymentData,
        StoreManagerInterface $storeManager,
        ResolverInterface $localeResolver,
        OrderManagementInterface $orderManagement
    ) {
        $this->_gatewayConfig = $gatewayConfig;
        $this->_objectManager = $objectManager;
        $this->_paymentData   = $paymentData;
        $this->_storeManager  = $storeManager;
        $this->_localeResolver = $localeResolver;
        $this->orderManagement = $orderManagement;

        $this->_scopeConfig   = $context->getScopeConfig();

        parent::__construct($context);
    }

    /**
     * Creates an Instance of the Helper
     * @param  \Magento\Framework\ObjectManagerInterface $objectManager
     * @return VUB\ECard\Helper\Data
     */
    public static function getInstance($objectManager)
    {
        return $objectManager->create(
            get_class()
        );
    }

    protected function getGatewayConfig() {
        return $this->_gatewayConfig;
    }

    /**
     * Get an Instance of the Magento Object Manager
     * @return \Magento\Framework\ObjectManagerInterface
     */
    protected function getObjectManager()
    {
        return $this->_objectManager;
    }

    /**
     * Get an Instance of the Magento Store Manager
     * @return \Magento\Store\Model\StoreManagerInterface
     */
    protected function getStoreManager()
    {
        return $this->_storeManager;
    }

    /**
     * Get an Instance of the Magento UrlBuilder
     * @return \Magento\Framework\UrlInterface
     */
    public function getUrlBuilder()
    {
        return $this->_urlBuilder;
    }

    public function getUrl($route)
    {
        return $this->_getUrl($route);
    }

    /**
     * Get an Instance of the Magento Scope Config
     * @return \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected function getScopeConfig()
    {
        return $this->_scopeConfig;
    }

    /**
     * Get an Instance of the Magento Core Locale Object
     * @return \Magento\Framework\Locale\ResolverInterface
     */
    protected function getLocaleResolver()
    {
        return $this->_localeResolver;
    }

    /**
     * Get an Instance of VUB eCard payment gateway
     * @return VubEcard|null
     */
    public function getPaymentGateway(Order $order)
    {
        $orderPrice = $order->getBaseGrandTotal();
        $variableSymbol = str_pad($order->getIncrementId(), 10, "0", STR_PAD_LEFT);
        $currencyISOCode = Currency::getCurrencyNumberByCode($this->_storeManager->getStore()->getCurrentCurrencyCode());

        try {
            $successUrl = $this->getSuccessUrl($order->getIncrementId());
            $failureUrl = $this->getFailureUrl($order->getIncrementId());

            $gateway = new VubEcard(
                $this->_gatewayConfig->getCustomerId(),
                $this->_gatewayConfig->getStoreKey(),
                $currencyISOCode,
                $this->_gatewayConfig->isSandbox()
            );

            $gateway->setCallbackUrlSuccesfull($successUrl);
            $gateway->setCallbackUrlError($failureUrl);

            $gateway->setOrderDetails($variableSymbol, (double)$orderPrice);

            return $gateway;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @throws NoSuchEntityException If given store doesn't exist.
     * @return string
     */
    public function getSuccessUrl($orderId) {
        return $this->getStoreManager()->getStore()->getBaseUrl() . 'vubecard/payment/success' . ($orderId ? "?orderId=$orderId" : '');
    }

    /**
     * @param string
     * @throws NoSuchEntityException If given store doesn't exist.
     * @return string
     */
    public function getFailureUrl($orderId) {
        return $this->getStoreManager()->getStore()->getBaseUrl() . 'vubecard/payment/failure' . ($orderId ? "?orderId=$orderId" : '');;
    }

    /**
     * Get Store code
     * @throws NoSuchEntityException If given store doesn't exist.
     * @return string
     */
    public function getStoreCode()
    {
        return $this->getStoreManager()->getStore()->getCode();
    }

    /**
     * Cancel order with specified comment message
     *
     * @return Mixed
     */
    public function cancelOrder($order, $comment)
    {

        if(!empty($comment)) {
            $comment = 'VUB_eCard :: ' . $comment;
        }
        if ($order->getState() != Order::STATE_CANCELED) {
            $order->registerCancellation($comment)->save();
            return true;
        }
        return false;
    }

    public function sendOrderEmail($order) {
        $result = true;
        try{
            if($order->getState() != $order::STATE_PROCESSING) {
                $orderCommentSender = $this->_objectManager
                    ->create('Magento\Sales\Model\Order\Email\Sender\OrderCommentSender');
                $orderCommentSender->send($order, true, '');
            }
            else{
                $this->orderManagement->notify($order->getEntityId());
            }
        } catch (\Exception $e) {
            $result = false;
            $this->_logger->critical($e);
        }

        return $result;
    }

    public function setHeaders()
    {
        $cookie_timeout = 3600;
        $cookie_domain = 'https://magento.loc';//$this->_storeManager->getStore()->getBaseUrl();
        $session_secure = true;
        $cookie_httponly = true;

        if (PHP_VERSION_ID >= 70300) {
            session_set_cookie_params([
                'lifetime' => $cookie_timeout,
                'path' => '/',
                'domain' => $cookie_domain,
                'secure' => $session_secure,
                'httponly' => $cookie_httponly,
                'samesite' => 'None'
            ]);
        } else {
            session_set_cookie_params(
                $cookie_timeout,
                '/; samesite=None',
                $cookie_domain,
                $session_secure,
                $cookie_httponly
            );
        }
    }
}
