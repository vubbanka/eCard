<?php

namespace VUB\ECard\Helper;

class Currency {

    const CURRENCY_CODE_TO_NUMBER_MAP = [
        'CZK' => 840,
        'EUR' => 978,
        'GBP' => 826,
        'HUF' => 348,
        'CHF' => 756,
        'PLN' => 985,
        'RON' => 946,
        'USD' => 840,
    ];

    public static function getCurrencyNumberByCode($currencyCode)
    {
        if (isset(self::CURRENCY_CODE_TO_NUMBER_MAP[$currencyCode])) {
            return self::CURRENCY_CODE_TO_NUMBER_MAP[$currencyCode];
        }

        return null;
    }
}
